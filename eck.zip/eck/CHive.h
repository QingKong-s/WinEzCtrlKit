#pragma once
#include "Utility.h"

ECK_NAMESPACE_BEGIN
constexpr inline size_t InitCount = 32;
using T = int;

class CHive
{

};
ECK_NAMESPACE_END