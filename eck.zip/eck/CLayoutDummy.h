﻿#pragma once
#include "CLayoutBase.h"

ECK_NAMESPACE_BEGIN
class CLayoutDummy : public CLayoutBase {};
ECK_NAMESPACE_END