﻿#pragma once
#include "CWnd.h"

ECK_NAMESPACE_BEGIN
class CWindowMask : public CWnd
{
private:

public:
	HWND Create(HWND hParent, int x, int y, int cx, int cy, UINT uFlags)
	{

	}
};
ECK_NAMESPACE_END